 
<h2  style="font-weight:normal;">Sales Orders are only available in  the premium version called WpShopcart. Please email n.showket@gmail.com or visit http://smartwpplugin.com for more details. </h2>
 